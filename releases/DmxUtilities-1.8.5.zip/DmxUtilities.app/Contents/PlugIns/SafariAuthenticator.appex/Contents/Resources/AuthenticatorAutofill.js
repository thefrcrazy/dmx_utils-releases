(() => {
    "use strict";
    // Only the top frame handles requests; it may inspect same-origin frames.
    if (window.top !== window || typeof safari === "undefined") return;
    let plan = null;
    const requestPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const otpPattern = /(?:^|[^a-z])(?:otp|totp|2fa|mfa|otc)(?:[^a-z]|$)|otp(?:code|token)|one[\s_-]*time[\s_-]*(?:code|password)|(?:verification|security|authentication|authentification|authenticator|auth|login|challenge|verif(?:ication)?|securite)[\s_-]*code|code[\s_-]*(?:de[\s_-]*)?(?:verification|security|authentication|authentification|auth|verif(?:ication)?|securite)|passcode|mot de passe a usage unique|two[\s_-]*factor|deux facteurs|code.{0,40}(?:authenticator|authentificateur)/;
    const excludedPattern = /postal|zipcode|zip-code|coupon|promo|gift|discount|cvv|cvc|credit|card.number|iban|recovery|backup|recuperation|secours|api[\s_-]*(?:key|token)|access[\s_-]*token|client[\s_-]*secret/;
    const normalize = value => String(value || "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const description = input => normalize([
        input.name, input.id, input.getAttribute("aria-label"), input.getAttribute("placeholder"),
        ...Array.from(input.labels || [], label => label.textContent),
        ...(input.getAttribute("aria-labelledby") || "").split(/\s+/).map(id => input.ownerDocument.getElementById(id)?.textContent)
    ].join(" "));
    const visibleElement = element => {
        try {
            if (!element.isConnected || element.closest('[hidden], [inert], [aria-hidden="true"]')) return false;
            const owner = element.ownerDocument.defaultView;
            if (!owner) return false;
            if (owner !== window) {
                const frame = owner.frameElement;
                if (!frame || frame.contentDocument !== element.ownerDocument || !visibleElement(frame)) return false;
            }
            if (typeof element.checkVisibility === "function" && !element.checkVisibility({checkOpacity: true, checkVisibilityCSS: true})) return false;
            const style = owner.getComputedStyle(element);
            const rect = element.getBoundingClientRect();
            return style.visibility !== "hidden" && style.display !== "none" && style.opacity !== "0" && rect.width > 0 && rect.height > 0;
        } catch (_) { return false; }
    };
    const visible = input => !input.disabled && !input.readOnly && ["text", "tel", "number"].includes(input.type) && visibleElement(input);
    const marked = input => !excludedPattern.test(description(input)) &&
        (input.autocomplete.split(/\s+/).includes("one-time-code") || otpPattern.test(description(input)));

    function inputsIn(root, results, depth = 0) {
        if (depth > 8 || results.length > 200) return;
        for (const input of root.querySelectorAll("input")) if (visible(input)) results.push(input);
        for (const node of root.querySelectorAll("*")) if (node.shadowRoot) inputsIn(node.shadowRoot, results, depth + 1);
        for (const frame of root.querySelectorAll("iframe")) {
            try {
                // contentDocument is unavailable for foreign/opaque origins.
                if (visibleElement(frame) && frame.contentDocument) inputsIn(frame.contentDocument, results, depth + 1);
            } catch (_) { /* Cross-origin frames never receive codes. */ }
        }
    }

    function chooseTargets(digits) {
        const inputs = [];
        inputsIn(document, inputs);
        if (inputs.length > 200) return {status: "no-field"};
        const candidates = inputs.filter(input => input.maxLength !== 1 && marked(input) &&
            (input.maxLength < 0 || input.maxLength >= digits)).map(input => [input]);
        const groups = new Map();
        for (const input of inputs) {
            if (input.maxLength !== 1 || excludedPattern.test(description(input))) continue;
            const group = input.closest('fieldset, [role="group"], [data-otp-group]') || input.form || input.parentElement || input.getRootNode();
            if (!groups.has(group)) groups.set(group, []);
            groups.get(group).push(input);
        }
        for (const [group, cells] of groups) {
            const context = normalize([group.id, group.getAttribute?.("aria-label"), group.querySelector("legend")?.textContent, group.textContent?.slice(0, 600)].join(" "));
            const numeric = cells.every(input => input.inputMode === "numeric" || input.type === "number" || input.getAttribute("pattern") === "[0-9]");
            if (cells.length === digits && (cells.some(marked) || (numeric && otpPattern.test(context) && !excludedPattern.test(context)))) candidates.push(cells);
        }
        const focused = candidates.filter(cells => cells.some(input => input === input.ownerDocument.activeElement || input === input.getRootNode().activeElement));
        if (focused.length === 1) return {status: "ready", targets: focused[0]};
        if (candidates.length === 1) return {status: "ready", targets: candidates[0]};
        return {status: candidates.length ? "ambiguous" : "no-field"};
    }

    function reply(data, stage, status) {
        safari.extension.dispatchMessage("dmx-otp-result", {requestID: data.requestID, origin: data.origin, stage, status});
    }

    safari.self.addEventListener("message", event => {
        if (!["dmx-otp-probe", "dmx-otp-fill"].includes(event.name)) return;
        const data = event.message;
        if (!data || typeof data.requestID !== "string" || !requestPattern.test(data.requestID) || data.origin !== location.origin) return;
        if (event.name === "dmx-otp-probe") {
            plan = null;
            if (!Number.isInteger(data.digits) || data.digits < 6 || data.digits > 8) return;
            const result = chooseTargets(data.digits);
            if (result.status === "ready") {
                plan = {id: data.requestID, url: location.href, digits: data.digits, targets: result.targets, until: Date.now() + 2000};
                const id = data.requestID;
                setTimeout(() => { if (plan?.id === id) plan = null; }, 2000);
            }
            reply(data, "probe", result.status);
            return;
        }
        const current = plan;
        plan = null;
        const selection = current ? chooseTargets(current.digits) : null;
        if (!current || current.id !== data.requestID || current.url !== location.href || current.until < Date.now() ||
            selection.status !== "ready" || selection.targets.length !== current.targets.length ||
            !selection.targets.every((input, index) => input === current.targets[index])) {
            reply(data, "fill", "changed");
            return;
        }
        if (typeof data.code !== "string" || !/^[0-9]{6,8}$/.test(data.code) || data.code.length !== current.digits ||
            !Number.isFinite(data.validUntil) || data.validUntil <= Date.now() || data.validUntil > Date.now() + 300000) {
            reply(data, "fill", "expired");
            return;
        }
        try {
            current.targets.forEach((input, index) => {
                const value = current.targets.length === 1 ? data.code : data.code[index];
                const owner = input.ownerDocument.defaultView;
                // The native setter also updates controlled React/Vue forms.
                Object.getOwnPropertyDescriptor(owner.HTMLInputElement.prototype, "value").set.call(input, value);
                input.dispatchEvent(new owner.Event("input", {bubbles: true, composed: true}));
                input.dispatchEvent(new owner.Event("change", {bubbles: true, composed: true}));
            });
            const filled = current.targets.every((input, index) => input.isConnected && input.value === (current.targets.length === 1 ? data.code : data.code[index]));
            // No button is clicked and no form submission is requested.
            reply(data, "fill", filled ? "filled" : "failed");
        } catch (_) { reply(data, "fill", "failed"); }
    });
})();
